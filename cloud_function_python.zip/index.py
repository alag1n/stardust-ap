import json
import base64
import os
import time
import requests


def uploadToGitHub(request):
    """Cloud function to upload photos to GitHub"""
    
    # Enable CORS
    request.headers['Access-Control-Allow-Origin'] = '*'
    request.headers['Access-Control-Allow-Methods'] = 'GET, POST, OPTIONS'
    request.headers['Access-Control-Allow-Headers'] = 'Content-Type'
    
    # Handle preflight OPTIONS request
    if request.method == 'OPTIONS':
        return ('', 204, {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type'
        })
    
    try:
        if request.method != 'POST':
            return json.dumps({'error': 'Method not allowed'}), 405
        
        # Get JSON data
        data = request.get_json()
        
        # Support both formats: {'data': base64Content} and {'content': content, 'fileName': fileName, 'githubToken': githubToken}
        base64_content = data.get('data') or data.get('content')
        file_name = data.get('fileName') or f"photo_{int(time.time() * 1000)}.jpg"
        github_token = data.get('githubToken') or os.environ.get('GITHUB_TOKEN') or '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'
        
        if not base64_content:
            return json.dumps({'error': 'Missing image data'}), 400
        
        if not github_token:
            return json.dumps({'error': 'GitHub token not provided'}), 400
        
        # Validate file type (only allow images)
        allowed_types = ['jpg', 'jpeg', 'png', 'gif']
        file_extension = file_name.split('.')[-1].lower()
        if file_extension not in allowed_types:
            return json.dumps({'error': 'Invalid file type'}), 400
        
        # Limit file size to 5MB
        try:
            buffer = base64.b64decode(base64_content)
            if len(buffer) > 5 * 1024 * 1024:
                return json.dumps({'error': 'File size exceeds 5MB limit'}), 400
        except Exception as e:
            return json.dumps({'error': f'Invalid base64 data: {str(e)}'}), 400
        
        # Upload to GitHub
        github_url = f"https://api.github.com/repos/alag1n/stardust-images/contents/photos/{file_name}"
        
        headers = {
            'Authorization': f'token {github_token}',
            'Content-Type': 'application/json',
            'User-Agent': 'Stardust-App'
        }
        
        response = requests.put(
            github_url,
            headers=headers,
            json={
                'content': base64_content,
                'message': f'Upload photo {file_name}'
            }
        )
        
        if response.status_code != 201:
            error_data = response.json() if response.text else {}
            raise Exception(f'GitHub API error: {response.status_code} - {error_data}')
        
        response_data = response.json()
        download_url = response_data['content']['download_url'].replace(
            'api.github.com/repos', 'raw.githubusercontent.com'
        ).replace('/contents/', '/')
        
        return json.dumps({
            'success': True,
            'downloadUrl': download_url,
            'fileName': file_name
        }), 200
        
    except Exception as error:
        print(f'Upload error: {str(error)}')
        return json.dumps({
            'success': False,
            'error': str(error)
        }), 500
