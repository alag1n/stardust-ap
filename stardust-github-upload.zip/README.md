# 🌌 Stardust Dating App

Flutter веб-приложение для знакомств с космическим дизайном.

## 🚀 Технологии

- **Flutter** - фронтенд
- **Firebase** - аутентификация и база данных
- **Vercel** - хостинг

## 📦 Структура проекта

```
├── stardust/           # Flutter приложение
│   ├── lib/           # Исходный код
│   ├── build/         # Скомпилированный веб (игнорируется в git)
│   └── pubspec.yaml   # Зависимости Flutter
├── vercel.json        # Конфигурация Vercel
└── firestore.rules    # Правила Firestore
```

## 🔧 Локальная разработка

```bash
# Установить Flutter dependencies
cd stardust
flutter pub get

# Запустить в режиме разработки
flutter run -d web-server --web-port=8080

# Скомпилировать для продакшена
flutter build web --release
```

## 🌐 Деплой на Vercel

1. **Установи Vercel CLI** (опционально):
```bash
npm install -g vercel
```

2. **Загрузи на GitHub**:
```bash
git add .
git commit -m "Initial commit"
git push origin main
```

3. **Подключи в Vercel**:
- Зайди на https://vercel.com/new
- Выбери свой репозиторий
- Vercel автоматически определит настройки из `vercel.json`
- Нажми Deploy

## ⚙️ Настройка домена

1. В панели Vercel перейди в **Settings → Domains**
2. Добавь домен: `stardust-kolovrats.ru`
3. В **NIC.RU** настрой DNS:
   - **Тип**: A
   - **Имя**: @
   - **Значение**: 76.76.21.21
   - **TTL**: 3600

Или используй CNAME:
   - **Тип**: CNAME
   - **Имя**: www
   - **Значение**: cname.vercel-dns.com

## 🔥 Настройка Firebase

1. Создай проект на https://console.firebase.google.com/
2. Добавь веб-приложение
3. Скопируй конфигурацию в `stardust/lib/firebase_options.dart`
4. Настрой Firestore Rules из `firestore.rules`
5. Включи Authentication (Email/Password)

## 📱 Функции

- ✅ Регистрация и аутентификация
- ✅ Загрузка фото (до 6 штук, base64 в Firestore)
- ✅ Лайки и взаимные匹配
- ✅ Чат для взаимных匹配
- ✅ Истории (Stories)
- ✅ Premium-функции

## 🛠 Сборка для продакшена

```bash
cd stardust
flutter build web --release --base-href=/
```

## 📄 Лицензия

MIT License