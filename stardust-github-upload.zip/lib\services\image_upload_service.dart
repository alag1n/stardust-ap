import 'dart:typed_data';
import 'package:image_picker/image_picker.dart';
import 'dart:convert';

class ImageUploadService {
  static final ImageUploadService _instance = ImageUploadService._internal();
  factory ImageUploadService() => _instance;
  ImageUploadService._internal();

  final ImagePicker _picker = ImagePicker();

  Future<List<XFile>> pickFromGallery() async {
    final XFile? image = await _picker.pickImage(
      source: ImageSource.gallery,
      maxWidth: 800,
      maxHeight: 800,
      imageQuality: 70,
    );
    if (image == null) return [];
    return [image];
  }
    
  Future<List<XFile>> pickFromCamera() async {
    final XFile? image = await _picker.pickImage(
      source: ImageSource.camera,
      maxWidth: 800,
      maxHeight: 800,
      imageQuality: 70,
    );
    if (image == null) return [];
    return [image];
  }
    
  /// Convert XFile to base64 string (simple, no external API)
  Future<String> uploadImage({
    required dynamic file,
    required String userId,
    String folder = 'photos',
  }) async {
    final XFile xFile = file as XFile;
    
    // Read file bytes
    final Uint8List bytes = await xFile.readAsBytes();
    
    // Convert to base64 with data URI prefix
    final base64String = base64Encode(bytes);
    final mimeType = _getMimeType(xFile.path);
    
    return 'data:$mimeType;base64,$base64String';
  }
  
  String _getMimeType(String path) {
    if (path.toLowerCase().endsWith('.png')) return 'image/png';
    if (path.toLowerCase().endsWith('.gif')) return 'image/gif';
    if (path.toLowerCase().endsWith('.webp')) return 'image/webp';
    return 'image/jpeg';
  }
  
  String getDefaultAvatar({String gender = 'other'}) {
    return 'https://via.placeholder.com/100?text=$gender';
  }
  
  Future<String> uploadToFirebase({
    required dynamic file,
    required String userId,
    String folder = 'avatars',
  }) async {
    return uploadImage(file: file, userId: userId, folder: folder);
  }
}
  
