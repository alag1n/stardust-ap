const functions = require('@google-cloud/functions-framework');
const fetch = require('node-fetch');

functions.http('uploadToGitHub', async (req, res) => {
  // Enable CORS
  res.set('Access-Control-Allow-Origin', '*');
  res.set('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.set('Access-Control-Allow-Headers', 'Content-Type');
  
  // Handle preflight OPTIONS request
  if (req.method === 'OPTIONS') {
    res.status(204).send('');
    return;
  }
  
  try {
    if (req.method !== 'POST') {
      res.status(405).json({ error: 'Method not allowed' });
      return;
    }
    
    // Поддержка двух форматов: {'data': base64Content} и {'content': content, 'fileName': fileName, 'githubToken': githubToken}
    const { data, content, fileName, githubToken } = req.body;
    
    const base64Content = data || content;
    const finalFileName = fileName || `photo_${Date.now()}.jpg`;
    const finalGithubToken = githubToken || process.env.GITHUB_TOKEN;
    
    if (!base64Content) {
      res.status(400).json({ error: 'Missing image data' });
      return;
    }
    
    if (!finalGithubToken) {
      res.status(400).json({ error: 'GitHub token not provided' });
      return;
    }
    
    // Validate file type (only allow images)
    const allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
    const fileExtension = finalFileName.split('.').pop().toLowerCase();
    if (!allowedTypes.includes(fileExtension)) {
      res.status(400).json({ error: 'Invalid file type' });
      return;
    }
    
    // Limit file size to 5MB
    const buffer = Buffer.from(base64Content, 'base64');
    if (buffer.length > 5 * 1024 * 1024) {
      res.status(400).json({ error: 'File size exceeds 5MB limit' });
      return;
    }
    
    // Upload to GitHub
    const githubUrl = `https://api.github.com/repos/alag1n/stardust-images/contents/photos/${finalFileName}`;
    
    const response = await fetch(githubUrl, {
      method: 'PUT',
      headers: {
        'Authorization': `token ${finalGithubToken}`,
        'Content-Type': 'application/json',
        'User-Agent': 'Stardust-App'
      },
      body: JSON.stringify({
        content: base64Content,
        message: `Upload photo ${finalFileName}`
      })
    });
    
    if (!response.ok) {
      const errorData = await response.json().catch(() => ({}));
      throw new Error(`GitHub API error: ${response.status} - ${JSON.stringify(errorData)}`);
    }
    
    const responseData = await response.json();
    const downloadUrl = responseData.content.download_url.replace('api.github.com/repos', 'raw.githubusercontent.com').replace('/contents/', '/');
    
    res.json({
      success: true,
      downloadUrl: downloadUrl,
      fileName: finalFileName
    });
    
  } catch (error) {
    console.error('Upload error:', error);
    res.status(500).json({
      success: false,
      error: error.message || 'Internal server error'
    });
  }
});