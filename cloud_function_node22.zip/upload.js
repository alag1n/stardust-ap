// Yandex Cloud Function handler
function uploadToGitHub(request, context) {
  const corsHeaders = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': '*',
    'Access-Control-Max-Age': '3600'
  };
  
  // Always return 200 for any request to ensure CORS works
  if (request.method === 'OPTIONS' || !request.method) {
    return {
      statusCode: 200,
      headers: corsHeaders,
      body: 'OK'
    };
  }
  
  if (request.method !== 'POST') {
    return {
      statusCode: 405,
      headers: corsHeaders,
      body: JSON.stringify({ error: 'Method not allowed' })
    };
  }
  
  try {
    const body = request.body || {};
    const { data, content } = body;
    const base64Content = data || content;
    const fileName = request.queryParams?.filename || body.fileName || `photo_${Date.now()}.jpg`;
    const githubToken = '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';
    
    if (!base64Content) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'No data provided' })
      };
    }
    
    // Validate file type
    const allowedTypes = ['jpg', 'jpeg', 'png', 'gif'];
    const fileExtension = fileName.split('.').pop().toLowerCase();
    if (!allowedTypes.includes(fileExtension)) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'Invalid file type' })
      };
    }
    
    // Limit file size to 5MB
    const buffer = Buffer.from(base64Content, 'base64');
    if (buffer.length > 5 * 1024 * 1024) {
      return {
        statusCode: 400,
        headers: corsHeaders,
        body: JSON.stringify({ error: 'File size exceeds 5MB limit' })
      };
    }
    
    // Upload to GitHub
    const githubUrl = `https://api.github.com/repos/alag1n/stardust-images/contents/photos/${fileName}`;
    
    return fetch(githubUrl, {
      method: 'PUT',
      headers: {
        'Authorization': `token ${githubToken}`,
        'Content-Type': 'application/json',
        'User-Agent': 'Stardust-App'
      },
      body: JSON.stringify({
        content: base64Content,
        message: `Upload photo ${fileName}`
      })
    }).then(githubResponse => {
      if (!githubResponse.ok) {
        return githubResponse.json().then(err => {
          throw new Error(`GitHub API error: ${githubResponse.status} - ${JSON.stringify(err)}`);
        });
      }
      return githubResponse.json();
    }).then(responseData => {
      const downloadUrl = responseData.content.download_url
        .replace('api.github.com/repos', 'raw.githubusercontent.com')
        .replace('/contents/', '/');
      
      return {
        statusCode: 200,
        headers: corsHeaders,
        body: JSON.stringify({
          success: true,
          downloadUrl: downloadUrl,
          fileName: fileName
        })
      };
    }).catch(error => {
      console.error('Upload error:', error);
      return {
        statusCode: 500,
        headers: corsHeaders,
        body: JSON.stringify({ success: false, error: error.message })
      };
    });
    
  } catch (error) {
    console.error('Error:', error);
    return {
      statusCode: 500,
      headers: corsHeaders,
      body: JSON.stringify({ error: error.message })
    };
  }
}

module.exports = { uploadToGitHub };